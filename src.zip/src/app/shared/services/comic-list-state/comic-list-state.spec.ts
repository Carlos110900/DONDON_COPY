import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComicListState } from './comic-list-state';

describe('ComicListState', () => {
  let component: ComicListState;
  let fixture: ComponentFixture<ComicListState>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ComicListState],
    }).compileComponents();

    fixture = TestBed.createComponent(ComicListState);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
