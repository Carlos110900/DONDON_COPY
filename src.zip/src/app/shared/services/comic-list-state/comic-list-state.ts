import { Component } from '@angular/core';

@Component({
  selector: 'app-comic-list-state',
  imports: [],
  templateUrl: './comic-list-state.html',
  styleUrl: './comic-list-state.scss',
})
export class ComicListState {}
