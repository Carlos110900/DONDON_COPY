export class AnonymousReader {}
