export class Administrator {}
