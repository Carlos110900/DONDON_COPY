export class RegisteredReader {}
