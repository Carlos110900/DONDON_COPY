export class BaseUser {}
